login = input("Digite o login: ")
senha = input("Digite a senha: ")

if login == senha: 
  print("Acesso concedido")
else:
  print("Acesso Negado")